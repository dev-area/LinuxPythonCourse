#!/bin/tcsh

foreach i (1 2 3 4 5)
    echo "Number: $i"

    if ($i == 3) then
        echo "Found number 3!"
    else
        echo "Not 3"
    endif
end

echo "Done!"
