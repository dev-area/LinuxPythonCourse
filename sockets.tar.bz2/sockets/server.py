import socket
HOST, PORT = "0.0.0.0", 5000 # 0.0.0.0 = every interface
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as srv:
	srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	srv.bind((HOST, PORT))
	srv.listen()
	print(f"listening on {HOST}:{PORT}")
	while True:
		conn, addr = srv.accept() # wait for a client
		with conn:
			print("connected:", addr)
			while data := conn.recv(1024): # b"" = closed
				conn.sendall(data.upper())
			print("closed:", addr) 
