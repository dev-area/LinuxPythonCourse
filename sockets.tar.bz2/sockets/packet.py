import socket

# ETH_P_ALL (0x0003) captures all Ethernet protocols
s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))

# Receive a single raw frame (up to 65535 bytes)
while True:
	raw_data, addr = s.recvfrom(65535)
	print(f"Captured {len(raw_data)} bytes from {addr}")
	print(raw_data)
